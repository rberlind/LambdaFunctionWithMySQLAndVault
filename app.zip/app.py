import sys
import logging
import pymysql
import hvac
import json
import os
import boto3

from base64 import b64decode

logger = logging.getLogger()
logger.setLevel(logging.INFO)

#rds settings
rds_host  = os.environ['RDS_HOST']

# Get database user name, and password from Vault
try:
    client = hvac.Client(url=os.environ['VAULT_ADDR'])
    session = boto3.Session()
    credentials = session.get_credentials()
    client.auth_aws("lambda-" + os.environ['ENV'] + "-role", credentials.access_key, credentials.secret_key, credentials.token)
    db_values = client.read('secret/' + os.environ['ENV'] + '/lambda/mysql/ExampleDB')
    db_name = 'ExampleDB'
    name = db_values['data']['db_user']
    logger.info("DB user is: " + str(name))
    password = db_values['data']['db_pwd']
    logger.info("DB password is: " + str(password))
except:
    logger.error("ERROR: Unexpected error: Could not connect to Vault.")
    sys.exit()

try:
    conn = pymysql.connect(rds_host, user=name, passwd=password, db=db_name, connect_timeout=5)
except:
    logger.error("ERROR: Unexpected error: Could not connect to MySql instance.")
    sys.exit()

logger.info("SUCCESS: Connection to RDS mysql instance succeeded")
def handler(event, context):
    """
    This function fetches content from mysql RDS instance
    """
    with conn.cursor() as cur:
        cur.execute("create table if not exists Employee ( EmpID  int NOT NULL AUTO_INCREMENT, Name varchar(255) NOT NULL, PRIMARY KEY (EmpID))")
        cur.execute('select count(*) from Employee')
        num_rows = cur.fetchone()
        logger.info("Employee table had " + str(num_rows) + " rows")
        cur.execute('insert into Employee (Name) values(%s)', (event['name']))
        conn.commit()
        cur.execute('select * from Employee where EmpID > %s', (num_rows) )
        item_count = 0
        for row in cur:
            item_count += 1
            logger.info(row)

    return "User %s with password %s added %d item(s) to the Employee table" %(name, password, item_count)
